const express = require('express');
const mongoose = require('mongoose');
const Contact = require('../models/contact');

const router = express.Router();

const UPDATABLE_FIELDS = ['name', 'phone', 'email'];

// Treat blank email as "no email" so contacts without an email can exist
// and an existing email can be cleared.
const normalizeEmail = (value) =>
    typeof value === 'string' && value.trim() === '' ? null : value;

async function findContact(id) {
    if (mongoose.isValidObjectId(id)) {
        const byObjectId = await Contact.findById(id);
        if (byObjectId) return byObjectId;
    }
    return Contact.findOne({ contactId: id });
}

// POST /contacts - add a new contact
router.post('/', async (req, res, next) => {
    try {
        const { contactId, name, phone, email } = req.body;
        const contact = await Contact.create({
            contactId,
            name,
            phone,
            email: normalizeEmail(email),
        });
        res.status(201).json({ success: true, data: contact });
    } catch (err) {
        next(err);
    }
});

// GET /contacts - fetch all contacts
router.get('/', async (req, res, next) => {
    try {
        const contacts = await Contact.find().sort({ createdAt: -1 });
        res.json({ success: true, count: contacts.length, data: contacts });
    } catch (err) {
        next(err);
    }
});

// GET /contacts/:id - fetch a single contact by id or contactId
router.get('/:id', async (req, res, next) => {
    try {
        const contact = await findContact(req.params.id);
        if (!contact) {
            return res.status(404).json({ success: false, message: 'Contact not found' });
        }
        res.json({ success: true, data: contact });
    } catch (err) {
        next(err);
    }
});

// PUT /contacts/:id - update contact details
router.put('/:id', async (req, res, next) => {
    try {
        const contact = await findContact(req.params.id);
        if (!contact) {
            return res.status(404).json({ success: false, message: 'Contact not found' });
        }

        for (const field of UPDATABLE_FIELDS) {
            if (Object.prototype.hasOwnProperty.call(req.body, field)) {
                contact[field] = field === 'email' ? normalizeEmail(req.body[field]) : req.body[field];
            }
        }

        await contact.save();
        res.json({ success: true, data: contact });
    } catch (err) {
        next(err);
    }
});

// DELETE /contacts/:id - delete a contact
router.delete('/:id', async (req, res, next) => {
    try {
        const contact = await findContact(req.params.id);
        if (!contact) {
            return res.status(404).json({ success: false, message: 'Contact not found' });
        }
        await contact.deleteOne();
        res.json({ success: true, message: 'Contact deleted successfully', data: contact });
    } catch (err) {
        next(err);
    }
});

module.exports = router;
