const BASE_URL = process.env.BASE_URL || 'http://localhost:5000';

let passed = 0;
let failed = 0;
const createdIds = [];

function check(name, condition, detail = '') {
    if (condition) {
        passed += 1;
        console.log(`  PASS  ${name}`);
    } else {
        failed += 1;
        console.log(`  FAIL  ${name}${detail ? ` -> ${detail}` : ''}`);
    }
}

async function request(method, path, body) {
    const options = { method, headers: {} };
    if (body !== undefined) {
        options.headers['Content-Type'] = 'application/json';
        options.body = typeof body === 'string' ? body : JSON.stringify(body);
    }
    const res = await fetch(`${BASE_URL}${path}`, options);
    let json = null;
    try {
        json = await res.json();
    } catch (err) {
        json = null;
    }
    return { status: res.status, body: json };
}

async function cleanup() {
    for (const id of createdIds) {
        await request('DELETE', `/contacts/${id}`);
    }
}

async function main() {
    console.log(`Running smoke tests against ${BASE_URL}\n`);

    // --- CREATE ---
    console.log('POST /contacts');
    const created = await request('POST', '/contacts', {
        name: 'John Doe',
        phone: '9876543210',
        email: 'john.doe@example.com',
    });
    check('returns 201', created.status === 201, `got ${created.status}`);
    check('returns success true', created.body?.success === true);
    check('auto-generates contactId', /^CNT-[A-F0-9]{8}$/.test(created.body?.data?.contactId || ''));
    const contactId = created.body?.data?.contactId;
    const mongoId = created.body?.data?._id;
    if (mongoId) createdIds.push(mongoId);

    const custom = await request('POST', '/contacts', {
        contactId: 'CNT-CUSTOM01',
        name: 'Jane Smith',
        phone: '1234567890',
        email: 'jane@example.com',
    });
    check('accepts a custom contactId', custom.status === 201, `got ${custom.status}`);
    if (custom.body?.data?._id) createdIds.push(custom.body.data._id);

    console.log('\nValidation errors');
    const noName = await request('POST', '/contacts', { phone: '1234567890' });
    check('missing name returns 400', noName.status === 400, `got ${noName.status}`);
    check('missing name error message', !!noName.body?.errors?.name);

    const badPhone = await request('POST', '/contacts', {
        name: 'Bad Phone',
        phone: '12345',
    });
    check('short phone returns 400', badPhone.status === 400, `got ${badPhone.status}`);
    check('phone error mentions 10 digits', /10 digits/.test(badPhone.body?.errors?.phone || ''));

    const alphaPhone = await request('POST', '/contacts', {
        name: 'Alpha Phone',
        phone: '12345abcde',
    });
    check('non-numeric phone returns 400', alphaPhone.status === 400, `got ${alphaPhone.status}`);

    const badEmail = await request('POST', '/contacts', {
        name: 'Bad Email',
        phone: '1234567890',
        email: 'not-an-email',
    });
    check('invalid email returns 400', badEmail.status === 400, `got ${badEmail.status}`);
    check('email error message', !!badEmail.body?.errors?.email);

    const dupEmail = await request('POST', '/contacts', {
        name: 'Dup Email',
        phone: '5555555555',
        email: 'john.doe@example.com',
    });
    check('duplicate email returns 409', dupEmail.status === 409, `got ${dupEmail.status}`);

    const dupContactId = await request('POST', '/contacts', {
        contactId: 'CNT-CUSTOM01',
        name: 'Dup Id',
        phone: '5555555555',
    });
    check('duplicate contactId returns 409', dupContactId.status === 409, `got ${dupContactId.status}`);

    const badJson = await request('POST', '/contacts', '{not valid json');
    check('malformed JSON returns 400', badJson.status === 400, `got ${badJson.status}`);

    // --- READ ---
    console.log('\nGET /contacts');
    const list = await request('GET', '/contacts');
    check('returns 200', list.status === 200, `got ${list.status}`);
    check('returns count >= 2', (list.body?.count || 0) >= 2, `count ${list.body?.count}`);

    console.log('\nGET /contacts/:id');
    const byObjectId = await request('GET', `/contacts/${mongoId}`);
    check('fetch by MongoDB _id', byObjectId.status === 200 && byObjectId.body?.data?._id === mongoId);

    const byContactId = await request('GET', `/contacts/${contactId}`);
    check('fetch by contactId', byContactId.status === 200 && byContactId.body?.data?.contactId === contactId);

    const notFound = await request('GET', '/contacts/CNT-DOESNOTEXIST');
    check('unknown contact returns 404', notFound.status === 404, `got ${notFound.status}`);

    // --- UPDATE ---
    console.log('\nPUT /contacts/:id');
    const updated = await request('PUT', `/contacts/${contactId}`, {
        name: 'John A. Doe',
        phone: '1111111111',
    });
    check('returns 200', updated.status === 200, `got ${updated.status}`);
    check('name updated', updated.body?.data?.name === 'John A. Doe');
    check('phone updated', updated.body?.data?.phone === '1111111111');

    const badUpdate = await request('PUT', `/contacts/${contactId}`, { phone: '99' });
    check('invalid update returns 400', badUpdate.status === 400, `got ${badUpdate.status}`);

    const updateNotFound = await request('PUT', '/contacts/CNT-NOPE', { name: 'X' });
    check('update unknown returns 404', updateNotFound.status === 404, `got ${updateNotFound.status}`);

    // --- DELETE ---
    console.log('\nDELETE /contacts/:id');
    const deleted = await request('DELETE', `/contacts/${contactId}`);
    check('returns 200', deleted.status === 200, `got ${deleted.status}`);
    const idx = createdIds.indexOf(mongoId);
    if (idx !== -1) createdIds.splice(idx, 1);

    const getDeleted = await request('GET', `/contacts/${contactId}`);
    check('deleted contact returns 404', getDeleted.status === 404, `got ${getDeleted.status}`);

    const deleteAgain = await request('DELETE', `/contacts/${contactId}`);
    check('second delete returns 404', deleteAgain.status === 404, `got ${deleteAgain.status}`);

    // --- NOT FOUND ROUTE ---
    console.log('\nUnknown route');
    const unknown = await request('GET', '/nope');
    check('unknown route returns 404 JSON', unknown.status === 404 && unknown.body?.success === false);

    await cleanup();

    console.log(`\n${passed} passed, ${failed} failed`);
    process.exit(failed > 0 ? 1 : 0);
}

main().catch(async (err) => {
    console.error('Smoke test aborted:', err.message);
    await cleanup();
    process.exit(1);
});
