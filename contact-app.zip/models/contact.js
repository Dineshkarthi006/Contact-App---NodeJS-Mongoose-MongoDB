const crypto = require('crypto');
const mongoose = require('mongoose');

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

const generateContactId = () => `CNT-${crypto.randomBytes(4).toString('hex').toUpperCase()}`;

const ContactSchema = new mongoose.Schema(
    {
        contactId: {
            type: String,
            required: [true, 'contactId is required'],
            unique: true,
            trim: true,
            immutable: true,
            default: generateContactId,
        },
        name: {
            type: String,
            required: [true, 'Name is required'],
            trim: true,
        },
        phone: {
            type: String,
            required: [true, 'Phone is required'],
            match: [/^\d{10}$/, 'Phone must be exactly 10 digits'],
            trim: true,
        },
        email: {
            type: String,
            trim: true,
            lowercase: true,
            match: [EMAIL_REGEX, 'Please provide a valid email address'],
        },
    },
    {
        timestamps: true,
        toJSON: { virtuals: true },
        toObject: { virtuals: true },
    }
);

// Unique index on email that only applies when the field exists,
// so multiple contacts without an email are allowed.
ContactSchema.index(
    { email: 1 },
    { unique: true, partialFilterExpression: { email: { $exists: true, $type: 'string' } } }
);

module.exports = mongoose.model('Contact', ContactSchema);
