require('dotenv').config();

const express = require('express');
const mongoose = require('mongoose');
const contactRoutes = require('./routes/contacts');
const { notFound, errorHandler } = require('./middleware/error');

const app = express();
const port = process.env.PORT || 5000;
const DB_NAME = process.env.DB_NAME || 'contact_management';

app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header(
        'Access-Control-Allow-Headers',
        'Origin, X-Requested-With, Content-Type, Accept'
    );
    next();
});

app.use(express.json());

app.get('/', (req, res) => {
    res.json({
        success: true,
        message: 'Contact Management System API',
        endpoints: {
            'POST /contacts': 'Add a new contact',
            'GET /contacts': 'Fetch all contacts',
            'GET /contacts/:id': 'Fetch a contact by id or contactId',
            'PUT /contacts/:id': 'Update a contact',
            'DELETE /contacts/:id': 'Delete a contact',
        },
    });
});

app.use('/contacts', contactRoutes);

app.use(notFound);
app.use(errorHandler);

mongoose
    .connect(process.env.MONGO_DB_URI, { dbName: DB_NAME })
    .then(() => {
        console.log(`Database "${DB_NAME}" connected successfully`);
        app.listen(port, () => {
            console.log(`Server running on port ${port}`);
        });
    })
    .catch((err) => {
        console.error('Failed to connect to MongoDB:', err.message);
        process.exit(1);
    });
