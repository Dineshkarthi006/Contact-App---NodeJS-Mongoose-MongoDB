# Contact Management System

A RESTful API for managing personal and professional contacts. Built with Node.js, Express.js, MongoDB, and Mongoose.

## Features

- Create, Read, Update, and Delete (CRUD) contacts
- Automatic generation of unique `contactId`
- Validation for name, phone (10-digit), and email format
- Duplicate email and contactId prevention
- Proper error handling for validation, not found, and malformed data

## Tech Stack

- Node.js
- Express.js
- MongoDB
- Mongoose
- dotenv
- nodemon

## Prerequisites

- Node.js (v18+ or v22+)
- MongoDB instance (local or remote)

## Setup Instructions

1. **Clone the repository**

   ```bash
   git clone <your-repo-url>
   cd contact-management-system
   ```

2. **Install dependencies**

   ```bash
   npm install
   ```

3. **Configure environment variables**

   Create a `.env` file in the root directory with the following:

   ```env
   MONGO_DB_URI=mongodb://user_455g6xq8q:p455g6xq8q@db01.dbhost.dev:5050/db_455g6xq8q
   PORT=5000
   ```

   - The application connects to the database `contact_management` by default.
   - Adjust `PORT` if needed.

4. **Run the application**

   - Development mode (with hot reload):
     ```bash
     npm run dev
     ```
   - Production mode:
     ```bash
     npm start
     ```

5. **Verify the server**

   Open `http://localhost:5000/` in your browser or API client. You should see a JSON response with available endpoints.

## API Endpoints

| Method | Endpoint         | Description                                     |
|--------|------------------|-------------------------------------------------|
| GET    | `/`              | Health/info endpoint with available routes      |
| POST   | `/contacts`      | Add a new contact                              |
| GET    | `/contacts`      | Fetch all contacts (newest first)               |
| GET    | `/contacts/:id`  | Fetch a contact by MongoDB `_id` or `contactId`|
| PUT    | `/contacts/:id`  | Update contact details                         |
| DELETE | `/contacts/:id`  | Delete a contact                              |

## Contact Schema

| Field      | Type   | Constraints                                    |
|------------|--------|-----------------------------------------------|
| contactId  | String | Unique, automatically generated (e.g. `CNT-XXXXXXXX`) |
| name       | String | Required                                       |
| phone      | String | Required, must be exactly 10 digits            |
| email      | String | Must be valid email format, unique (if provided) |

## Example Requests & Responses

### 1. Create a Contact (POST /contacts)

**Request:**

```json
{
  "name": "John Doe",
  "phone": "9876543210",
  "email": "john.doe@example.com"
}
```

**Success Response (201):**

```json
{
  "success": true,
  "data": {
    "_id": "68e65e3e8f2d9e34a5f3a822",
    "contactId": "CNT-9A3F4821",
    "name": "John Doe",
    "phone": "9876543210",
    "email": "john.doe@example.com",
    "createdAt": "2025-10-08T10:45:18.426Z",
    "updatedAt": "2025-10-08T10:45:18.426Z",
    "__v": 0
  }
}
```

### 2. Get All Contacts (GET /contacts)

**Response (200):**

```json
{
  "success": true,
  "count": 2,
  "data": [
    {
      "_id": "68e65e3e8f2d9e34a5f3a822",
      "contactId": "CNT-9A3F4821",
      "name": "John Doe",
      "phone": "9876543210",
      "email": "john.doe@example.com",
      "createdAt": "2025-10-08T10:45:18.426Z",
      "updatedAt": "2025-10-08T10:45:18.426Z",
      "__v": 0
    }
  ]
}
```

### 3. Get Contact by ID (GET /contacts/:id)

Works with either MongoDB `_id` or the generated `contactId`.

**Example:** `GET /contacts/CNT-9A3F4821`

**Response (200):**

```json
{
  "success": true,
  "data": {
    "_id": "68e65e3e8f2d9e34a5f3a822",
    "contactId": "CNT-9A3F4821",
    "name": "John Doe",
    "phone": "9876543210",
    "email": "john.doe@example.com",
    "createdAt": "2025-10-08T10:45:18.426Z",
    "updatedAt": "2025-10-08T10:45:18.426Z",
    "__v": 0
  }
}
```

### 4. Update a Contact (PUT /contacts/:id)

**Request:**

```json
{
  "name": "John A. Doe",
  "phone": "1111111111"
}
```

**Response (200):**

```json
{
  "success": true,
  "data": {
    "_id": "68e65e3e8f2d9e34a5f3a822",
    "contactId": "CNT-9A3F4821",
    "name": "John A. Doe",
    "phone": "1111111111",
    "email": "john.doe@example.com",
    "createdAt": "2025-10-08T10:45:18.426Z",
    "updatedAt": "2025-10-08T10:46:32.104Z",
    "__v": 0
  }
}
```

### 5. Delete a Contact (DELETE /contacts/:id)

**Response (200):**

```json
{
  "success": true,
  "message": "Contact deleted successfully",
  "data": {
    "_id": "68e65e3e8f2d9e34a5f3a822",
    "contactId": "CNT-9A3F4821",
    "name": "John A. Doe",
    "phone": "1111111111",
    "email": "john.doe@example.com",
    "createdAt": "2025-10-08T10:45:18.426Z",
    "updatedAt": "2025-10-08T10:46:32.104Z",
    "__v": 0
  }
}
```

### Error Responses

| Status | Scenario                | Example |
|--------|------------------------|---------|
| 400    | Validation failed     | Invalid phone/email, missing required fields, malformed JSON |
| 404    | Contact not found     | No contact matches the provided ID |
| 409    | Duplicate entry       | Email or contactId already exists |
| 500    | Internal server error | Unexpected server issue |

## Testing

You can test all endpoints using [Postman](https://www.postman.com/) or [Thunder Client](https://www.thunderclient.com/). A simple smoke test script is included:

```bash
node scripts/smoke-test.js
```

Ensure the server is running before executing the test.

## License

ISC
