function notFound(req, res) {
    res.status(404).json({
        success: false,
        message: `Route ${req.method} ${req.originalUrl} not found`,
    });
}

// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
    // Malformed JSON body
    if (err.type === 'entity.parse.failed' || err instanceof SyntaxError) {
        return res.status(400).json({ success: false, message: 'Invalid JSON in request body' });
    }

    // Mongoose schema validation errors
    if (err.name === 'ValidationError') {
        const errors = {};
        for (const [field, detail] of Object.entries(err.errors || {})) {
            errors[field] = detail.message;
        }
        return res.status(400).json({ success: false, message: 'Validation failed', errors });
    }

    // Invalid ObjectId cast errors
    if (err.name === 'CastError') {
        return res.status(400).json({
            success: false,
            message: `Invalid value for ${err.path}: ${err.value}`,
        });
    }

    // Duplicate key errors (unique index violations)
    if (err.code === 11000) {
        const fields = Object.keys(err.keyValue || {});
        return res.status(409).json({
            success: false,
            message: `Duplicate value for: ${fields.join(', ')}`,
            errors: err.keyValue,
        });
    }

    console.error(err);
    return res.status(500).json({ success: false, message: 'Internal server error' });
}

module.exports = { notFound, errorHandler };
